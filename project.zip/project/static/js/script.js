document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('category');
    const dynamicFields = document.getElementById('dynamic-fields');
    
    categorySelect.addEventListener('change', function() {
        const category = this.value;
        dynamicFields.innerHTML = '';
        
        if (category === 'Автошины') {
            addField('Размер (например 175/85)', 'size', 'text');
            addDiameterField();
        } 
        else if (category === 'Аккумуляторы') {
            addTypeField();
        }
        else if (category === 'Антифриз') {
            addField('Объем (л)', 'volume', 'number');
        }
        else if (category === 'Моторные масла') {
            addField('Вязкость', 'viscosity', 'text');
        }
    });
    
    function addField(labelText, name, type) {
        const group = document.createElement('div');
        group.className = 'form-group';
        
        const label = document.createElement('label');
        label.textContent = labelText;
        
        const input = document.createElement('input');
        input.type = type;
        input.name = name;
        input.required = true;
        
        group.appendChild(label);
        group.appendChild(input);
        dynamicFields.appendChild(group);
    }
    
    function addDiameterField() {
        const group = document.createElement('div');
        group.className = 'form-group';
        
        const label = document.createElement('label');
        label.textContent = 'Диаметр (R)';
        
        const select = document.createElement('select');
        select.name = 'diameter';
        select.required = true;
        
        const options = ['17.5', '22.5'];
        options.forEach(opt => {
            const option = document.createElement('option');
            option.value = opt;
            option.textContent = opt;
            select.appendChild(option);
        });
        
        group.appendChild(label);
        group.appendChild(select);
        dynamicFields.appendChild(group);
    }
    
    function addTypeField() {
        const group = document.createElement('div');
        group.className = 'form-group';
        
        const label = document.createElement('label');
        label.textContent = 'Тип';
        
        const select = document.createElement('select');
        select.name = 'type';
        select.required = true;
        
        const options = ['маленький', 'большой'];
        options.forEach(opt => {
            const option = document.createElement('option');
            option.value = opt;
            option.textContent = opt;
            select.appendChild(option);
        });
        
        group.appendChild(label);
        group.appendChild(select);
        dynamicFields.appendChild(group);
    }
});
