from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///autoparts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key_here'
db = SQLAlchemy(app)

# Модели данных
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)
    brand = db.Column(db.String(100), nullable=False)
    details = db.Column(db.JSON)
    price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    sales = db.relationship('Sale', backref='product', lazy=True)

class Sale(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    sale_date = db.Column(db.DateTime, default=datetime.utcnow)

# Создаем БД при первом запуске
with app.app_context():
    db.create_all()

# Конфигурация категорий
CATEGORIES = {
    'Антифриз': {
        'fields': ['Бренд', 'Объем (л)', 'Цена', 'Количество'],
        'image': 'antifreeze.png'
    },
    'Моторные масла': {
        'fields': ['Бренд', 'Вязкость', 'Цена', 'Количество'],
        'image': 'motor_oil.png'
    },
    'Автошины': {
        'fields': ['Бренд', 'Размер (например 175/85)', 'Диаметр (R)', 'Цена', 'Количество'],
        'image': 'tires.png'
    },
    'Аккумуляторы': {
        'fields': ['Бренд', 'Тип (маленький/большой)', 'Цена', 'Количество'],
        'image': 'batteries.png'
    }
}

# Инициализация темы
@app.before_request
def before_request():
    if 'theme' not in session:
        session['theme'] = 'light'  # Тема по умолчанию

# Главная страница
@app.route('/')
def index():
    # Получаем количество товаров по категориям
    category_counts = {}
    for category in CATEGORIES:
        count = Product.query.filter_by(category=category).count()
        category_counts[category] = count
    
    return render_template('index.html', 
                           categories=CATEGORIES,
                           category_counts=category_counts,
                           current_theme=session['theme'])

# Страница категории
@app.route('/category/<cat_name>')
def category(cat_name):
    if cat_name not in CATEGORIES:
        flash('Категория не найдена', 'danger')
        return redirect(url_for('index'))
    
    products = Product.query.filter_by(category=cat_name).all()
    
    # Считаем общее количество товаров в категории
    total_quantity = sum(product.quantity for product in products)
    
    return render_template('category.html', 
                           cat_name=cat_name, 
                           products=products, 
                           cat_image=CATEGORIES[cat_name]['image'],
                           total_quantity=total_quantity,
                           current_theme=session['theme'])

# Добавление товара
@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        category = request.form['category']
        brand = request.form['brand']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        
        details = {}
        if category == 'Автошины':
            details = {
                'size': request.form['size'],
                'diameter': request.form['diameter']
            }
        elif category == 'Аккумуляторы':
            details = {'type': request.form['type']}
        elif category == 'Антифриз':
            details = {'volume': request.form['volume']}
        elif category == 'Моторные масла':
            details = {'viscosity': request.form['viscosity']}
        
        new_product = Product(
            category=category,
            brand=brand,
            details=details,
            price=price,
            quantity=quantity
        )
        
        db.session.add(new_product)
        db.session.commit()
        flash('Товар успешно добавлен!', 'success')
        return redirect(url_for('category', cat_name=category))
    
    return render_template('add_product.html', 
                           categories=CATEGORIES,
                           current_theme=session['theme'])

# Удаление товара
@app.route('/delete_product/<int:id>')
def delete_product(id):
    product = Product.query.get(id)
    if product:
        category_name = product.category
        db.session.delete(product)
        db.session.commit()
        flash('Товар успешно удален', 'success')
        return redirect(url_for('category', cat_name=category_name))
    else:
        flash('Товар не найден', 'danger')
        return redirect(url_for('index'))

# Управление продажами
@app.route('/sales', methods=['GET', 'POST'])
def sales():
    if request.method == 'POST':
        product_id = request.form.get('product_id')
        quantity = int(request.form['quantity'])
        
        if not product_id:
            flash('Выберите товар', 'danger')
            return redirect(url_for('sales'))
        
        product = Product.query.get(product_id)
        if not product:
            flash('Товар не найден', 'danger')
            return redirect(url_for('sales'))
        
        if product.quantity < quantity:
            flash('Недостаточно товара на складе', 'danger')
            return redirect(url_for('sales'))
        
        amount = product.price * quantity
        product.quantity -= quantity
        
        new_sale = Sale(
            product_id=product_id,
            quantity=quantity,
            amount=amount
        )
        
        db.session.add(new_sale)
        db.session.commit()
        flash('Продажа успешно зарегистрирована!', 'success')
        return redirect(url_for('sales'))
    
    products = Product.query.all()
    return render_template('sales.html', 
                           products=products,
                           current_theme=session['theme'])

# Отчет о продажах
@app.route('/sales_report')
def sales_report():
    # Получаем продажи за последние 7 дней
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=7)
    
    sales = Sale.query.filter(Sale.sale_date.between(start_date, end_date)).all()
    
    # Группируем по дням
    report = {}
    for sale in sales:
        date_str = sale.sale_date.strftime('%d %b')
        if date_str not in report:
            report[date_str] = 0
        report[date_str] += sale.amount
    
    # Сортируем по дате
    sorted_report = sorted(report.items(), key=lambda x: datetime.strptime(x[0], '%d %b'), reverse=True)
    
    return render_template('sales_report.html', 
                           report=sorted_report,
                           current_theme=session['theme'])

# Профиль пользователя
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':
        theme = request.form.get('theme')
        if theme in ['light', 'dark', 'ios']:
            session['theme'] = theme
            flash('Тема успешно изменена', 'success')
        else:
            flash('Некорректная тема', 'danger')
        return redirect(url_for('profile'))
    
    return render_template('profile.html', 
                           current_theme=session['theme'])

# Изменение темы
@app.route('/change_theme/<theme_name>')
def change_theme(theme_name):
    if theme_name in ['light', 'dark', 'ios']:
        session['theme'] = theme_name
        flash('Тема успешно изменена', 'success')
    else:
        flash('Некорректная тема', 'danger')
    return redirect(request.referrer or url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)