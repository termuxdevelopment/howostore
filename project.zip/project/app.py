from flask import Flask, render_template, request, redirect, url_for, jsonify
from models import db, Product, Sale
from datetime import datetime
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///autoparts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Создаем БД при первом запуске
with app.app_context():
    db.create_all()

# Категории товаров
CATEGORIES = {
    'Антифриз': {'fields': ['Бренд', 'Объем (л)', 'Цена', 'Количество']},
    'Моторные масла': {'fields': ['Бренд', 'Вязкость', 'Цена', 'Количество']},
    'Автошины': {'fields': ['Бренд', 'Размер (например 175/85)', 'Диаметр (R)', 'Цена', 'Количество']},
    'Аккумуляторы': {'fields': ['Бренд', 'Тип (маленький/большой)', 'Цена', 'Количество']}
}

@app.route('/')
def index():
    return render_template('index.html', categories=CATEGORIES.keys())

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        category = request.form['category']
        brand = request.form['brand']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        
        details = {}
        if category == 'Автошины':
            details = {
                'size': request.form['size'],
                'diameter': request.form['diameter']
            }
        elif category == 'Аккумуляторы':
            details = {'type': request.form['type']}
        elif category == 'Антифриз':
            details = {'volume': request.form['volume']}
        elif category == 'Моторные масла':
            details = {'viscosity': request.form['viscosity']}
        
        new_product = Product(
            category=category,
            brand=brand,
            details=details,
            price=price,
            quantity=quantity
        )
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('index'))
    
    return render_template('add_product.html', categories=CATEGORIES)

@app.route('/delete_product/<int:id>')
def delete_product(id):
    product = Product.query.get(id)
    db.session.delete(product)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/sales', methods=['GET', 'POST'])
def sales():
    if request.method == 'POST':
        product_type = request.form['product_type']
        quantity = int(request.form['quantity'])
        amount = float(request.form['amount'])
        
        new_sale = Sale(
            product_type=product_type,
            quantity=quantity,
            amount=amount
        )
        db.session.add(new_sale)
        db.session.commit()
        return redirect(url_for('sales'))
    
    return render_template('sales.html')

@app.route('/sales_report')
def sales_report():
    sales = Sale.query.all()
    report = {}
    for sale in sales:
        date_str = sale.sale_date.strftime('%Y-%m-%d')
        if date_str not in report:
            report[date_str] = 0
        report[date_str] += sale.amount
    
    return render_template('sales_report.html', report=report)

if __name__ == '__main__':
    app.run(debug=True)
