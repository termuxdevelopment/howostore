from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from models import db, Category, Product, Sale
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db.init_app(app)

with app.app_context():
    db.create_all()
    # Инициализация категорий
    categories = [
        ('Антифриз', 'antifriz.png'),
        ('Моторные масла', 'maslo.png'),
        ('Автошины', 'category-img7.png'),
        ('Аккумуляторы', 'akkumulyatori.png')
    ]
    for name, img in categories:
        if not Category.query.filter_by(name=name).first():
            db.session.add(Category(name=name, image=img))
    db.session.commit()

@app.route('/')
def index():
    categories = Category.query.all()
    products = Product.query.all()
    return render_template('index.html', categories=categories, products=products)

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    categories = Category.query.all()
    
    if request.method == 'POST':
        category_id = request.form['category']
        brand = request.form['brand']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        
        # Обработка специфичных полей
        size = None
        diameter = None
        
        category = Category.query.get(category_id)
        if category.name == 'Автошины':
            size = request.form['tire_size']
            diameter = float(request.form['diameter'])
        elif category.name == 'Аккумуляторы':
            size = request.form['battery_size']
        
        new_product = Product(
            name=f"{brand} {size or ''}",
            brand=brand,
            category_id=category_id,
            price=price,
            quantity=quantity,
            size=size,
            diameter=diameter
        )
        
        db.session.add(new_product)
        db.session.commit()
        flash('Товар успешно добавлен!', 'success')
        return redirect(url_for('index'))
    
    return render_template('add_product.html', categories=categories)

@app.route('/delete_product/<int:id>')
def delete_product(id):
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    flash('Товар удален!', 'warning')
    return redirect(url_for('index'))

@app.route('/sales')
def sales():
    return render_template('sales.html')

@app.route('/add_sale', methods=['GET', 'POST'])
def add_sale():
    products = Product.query.all()
    
    if request.method == 'POST':
        product_id = request.form['product']
        quantity = int(request.form['quantity'])
        
        product = Product.query.get(product_id)
        if product.quantity < quantity:
            flash('Недостаточно товара на складе!', 'danger')
            return redirect(url_for('add_sale'))
        
        amount = product.price * quantity
        new_sale = Sale(
            product_id=product_id,
            quantity=quantity,
            amount=amount
        )
        
        # Обновляем количество товара
        product.quantity -= quantity
        
        db.session.add(new_sale)
        db.session.commit()
        flash(f'Продажа оформлена! Сумма: {amount:,.2f} SUM', 'success')
        return redirect(url_for('sales'))
    
    return render_template('add_sale.html', products=products)

@app.route('/profit_report')
def profit_report():
    # Группировка по дням
    sales = Sale.query.all()
    profit_by_day = {}
    
    for sale in sales:
        date_str = sale.sale_date.strftime('%Y-%m-%d')
        if date_str not in profit_by_day:
            profit_by_day[date_str] = 0
        profit_by_day[date_str] += sale.amount
    
    # Форматирование для отображения
    report_data = []
    for date_str, amount in profit_by_day.items():
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        report_data.append({
            'date': date_obj.strftime('%d %b'),
            'amount': amount
        })
    
    # Сортировка по дате
    report_data.sort(key=lambda x: x['date'])
    
    return render_template('profit_report.html', report_data=report_data)

if __name__ == '__main__':
    app.run(debug=True)