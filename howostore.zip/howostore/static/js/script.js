// Обработчик для динамического отображения полей товара
document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('category-select');
    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            const tireFields = document.getElementById('tire-fields');
            const batteryFields = document.getElementById('battery-fields');
            
            tireFields.style.display = 'none';
            batteryFields.style.display = 'none';
            
            const selectedOption = this.options[this.selectedIndex].text;
            if (selectedOption === 'Автошины') {
                tireFields.style.display = 'block';
            } else if (selectedOption === 'Аккумуляторы') {
                batteryFields.style.display = 'block';
            }
        });
    }
});