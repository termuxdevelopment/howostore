from flask import Flask, render_template, request, redirect, url_for
from models import db, Category, Product
from sqlalchemy import or_

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:password@localhost/howo_store'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.route('/')
def index():
    categories = Category.query.all()
    return render_template('index.html', categories=categories)

@app.route('/category/<int:category_id>')
def show_category(category_id):
    category = Category.query.get_or_404(category_id)
    products = Product.query.filter_by(category_id=category.id).all()
    return render_template('category.html', category=category, products=products)

@app.route('/add', methods=['GET', 'POST'])
def add_product():
    categories = Category.query.all()
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        category_id = int(request.form['category'])
        attributes = request.form['attributes']
        new_product = Product(name=name, price=price, category_id=category_id, attributes=attributes)
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_product.html', categories=categories)

@app.route('/search')
def search():
    query = request.args.get('q', '')
    products = Product.query.filter(or_(Product.name.like(f"%{query}%"), Product.attributes.like(f"%{query}%"))).all()
    return render_template('search_results.html', products=products, query=query)

if __name__ == '__main__':
    app.run(debug=True)