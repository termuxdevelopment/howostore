from flask import Flask, render_template, request, redirect, url_for, flash
from models import db, Product, Sale
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'your_secret_key'

db.init_app(app)

# Create database tables
with app.app_context():
    db.create_all()

# List of categories
CATEGORIES = ['Анти-Фриз', 'Моторные масла', 'Авто-шины', 'Аккумуляторы']

def get_category_counts():
    return {category: Product.query.filter_by(category=category).count() for category in CATEGORIES}

@app.route('/')
def index():
    category_counts = get_category_counts()
    return render_template('index.html', categories=CATEGORIES, category_counts=category_counts)

@app.route('/category/<category>')
def category_page(category):
    if category not in CATEGORIES:
        flash('Категория не найдена!')
        return redirect(url_for('index'))
    products = Product.query.filter_by(category=category).all()
    total_quantity = sum(product.quantity for product in products)
    category_counts = get_category_counts()
    return render_template('category.html', category=category, products=products, total_quantity=total_quantity, categories=CATEGORIES, category_counts=category_counts)

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    category_counts = get_category_counts()
    if request.method == 'POST':
        category = request.form['category']
        brand = request.form['brand']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])

        if category == 'Авто-шины':
            size = request.form['size']
            diameter = request.form['diameter']
            product = Product(category=category, brand=brand, size=size, diameter=diameter, price=price, quantity=quantity)
        elif category == 'Аккумуляторы':
            size = request.form['battery_size']
            product = Product(category=category, brand=brand, size=size, price=price, quantity=quantity)
        else:
            product = Product(category=category, brand=brand, price=price, quantity=quantity)

        db.session.add(product)
        db.session.commit()
        flash('Товар успешно добавлен!')
        return redirect(url_for('index'))

    return render_template('add_product.html', categories=CATEGORIES, category_counts=category_counts)

@app.route('/delete_product/<int:id>')
def delete_product(id):
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    flash('Товар удалён!')
    return redirect(url_for('category_page', category=product.category))

@app.route('/sales', methods=['GET', 'POST'])
def sales():
    category_counts = get_category_counts()
    if request.method == 'POST':
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        sales = Sale.query.filter(Sale.date.between(start_date, end_date)).all()
        total_profit = sum(sale.profit for sale in sales)
        return render_template('sales.html', sales=sales, total_profit=total_profit, start_date=start_date, end_date=end_date, categories=CATEGORIES, category_counts=category_counts)
    
    sales = Sale.query.all()
    total_profit = sum(sale.profit for sale in sales)
    return render_template('sales.html', sales=sales, total_profit=total_profit, categories=CATEGORIES, category_counts=category_counts)

@app.route('/add_sale', methods=['GET', 'POST'])
def add_sale():
    category_counts = get_category_counts()
    if request.method == 'POST':
        product_type = request.form['product_type']
        category = request.form['category']
        quantity = int(request.form['quantity'])
        received = float(request.form['received'])
        date = datetime.strptime(request.form['date'], '%Y-%m-%d')

        # Deduct quantity from products in the selected category
        products = Product.query.filter_by(category=category).all()
        remaining_quantity = quantity
        for product in products:
            if remaining_quantity <= 0:
                break
            if product.quantity >= remaining_quantity:
                product.quantity -= remaining_quantity
                remaining_quantity = 0
            else:
                remaining_quantity -= product.quantity
                product.quantity = 0
        if remaining_quantity > 0:
            flash('Недостаточно товара на складе!')
            return redirect(url_for('add_sale'))

        # Calculate profit (received amount for simplicity)
        profit = received
        sale = Sale(product_type=product_type, category=category, quantity=quantity, received=received, profit=profit, date=date)
        db.session.add(sale)
        db.session.commit()
        flash('Продажа добавлена, количество товара обновлено!')
        return redirect(url_for('sales'))

    return render_template('add_sale.html', categories=CATEGORIES, category_counts=category_counts)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)