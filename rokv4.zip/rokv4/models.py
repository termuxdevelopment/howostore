# models.py

from flask_sqlalchemy import SQLAlchemy

# Создаём объект SQLAlchemy
db = SQLAlchemy()

# Модель для таблицы товаров (Product)
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)  # Категория товара
    brand = db.Column(db.String(100), nullable=False)    # Бренд
    size = db.Column(db.String(50), nullable=True)       # Размер (опционально)
    diameter = db.Column(db.String(10), nullable=True)   # Диаметр (для шин, опционально)
    price = db.Column(db.Float, nullable=False)          # Цена
    quantity = db.Column(db.Integer, nullable=False)     # Количество на складе

# Модель для таблицы продаж (Sale)
class Sale(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_type = db.Column(db.String(100), nullable=False)  # Тип продукта
    category = db.Column(db.String(50), nullable=False)       # Категория
    quantity = db.Column(db.Integer, nullable=False)          # Проданное количество
    received = db.Column(db.Float, nullable=False)            # Полученная сумма
    profit = db.Column(db.Float, nullable=False)              # Прибыль
    date = db.Column(db.Date, nullable=False)                 # Дата продажи