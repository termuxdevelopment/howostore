# config.py

# URI базы данных SQLite
SQLALCHEMY_DATABASE_URI = 'sqlite:///database.db'

# Отключение отслеживания изменений в SQLAlchemy (для оптимизации)
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Секретный ключ для управления сессиями и flash-сообщениями
SECRET_KEY = 'your_secret_key'  # Замените на свой уникальный ключ