from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)  # Анти-Фриз, Моторные масла и т.д.
    brand = db.Column(db.String(50), nullable=False)     # Бренд
    details = db.Column(db.String(100), nullable=False)  # Размер/Диаметр для шин, Размер для аккумуляторов и т.д.
    price = db.Column(db.Float, nullable=False)          # Цена
    quantity = db.Column(db.Integer, nullable=False)     # Количество

class Sale(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)            # Дата продажи
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)  # ID товара
    quantity = db.Column(db.Integer, nullable=False)     # Проданное количество
    revenue = db.Column(db.Float, nullable=False)        # Получено в руки