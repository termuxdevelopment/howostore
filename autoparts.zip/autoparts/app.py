from flask import Flask, render_template, request, redirect, url_for
from models import db, Product, Sale
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///car_parts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Главная страница - список товаров
@app.route('/')
def index():
    products = Product.query.all()
    return render_template('index.html', products=products)

# Добавление товара
@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        category = request.form['category']
        brand = request.form['brand']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])

        # Обработка деталей в зависимости от категории
        if category == 'Авто-шины':
            size = request.form['size']  # Например, 175*85
            diameter = request.form['diameter']  # 17.5 или 22.5
            details = f"Размер: {size}, Диаметр: {diameter}"
        elif category == 'Аккумуляторы':
            size = request.form['battery_size']  # Маленький/Большой
            details = f"Размер: {size}"
        else:
            details = request.form['details']  # Для остальных категорий просто текст

        new_product = Product(category=category, brand=brand, details=details, price=price, quantity=quantity)
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_product.html')

# Управление продажами
@app.route('/sales', methods=['GET', 'POST'])
def sales():
    if request.method == 'POST':
        date_str = request.form['date']
        product_id = int(request.form['product_id'])
        quantity = int(request.form['quantity'])
        revenue = float(request.form['revenue'])
        date = datetime.strptime(date_str, '%Y-%m-%d').date()

        # Добавление продажи
        new_sale = Sale(date=date, product_id=product_id, quantity=quantity, revenue=revenue)
        db.session.add(new_sale)

        # Обновление количества товара
        product = Product.query.get(product_id)
        product.quantity -= quantity
        db.session.commit()
        return redirect(url_for('sales'))

    sales = Sale.query.all()
    products = Product.query.all()
    
    # Подсчет прибыли по дням
    profit_by_date = {}
    for sale in sales:
        date_str = sale.date.strftime('%d %b')
        if date_str in profit_by_date:
            profit_by_date[date_str] += sale.revenue
        else:
            profit_by_date[date_str] = sale.revenue

    return render_template('sales.html', sales=sales, products=products, profit_by_date=profit_by_date)

# Инициализация базы данных
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)