document.addEventListener('DOMContentLoaded', function () {
    const categorySelect = document.getElementById('category');
    const tireFields = document.getElementById('tire_fields');
    const batteryFields = document.getElementById('battery_fields');

    if (categorySelect) {
        categorySelect.addEventListener('change', function () {
            tireFields.style.display = this.value === 'Авто-шины' ? 'block' : 'none';
            batteryFields.style.display = this.value === 'Аккумуляторы' ? 'block' : 'none';
        });
    }
});