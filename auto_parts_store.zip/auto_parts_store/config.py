# config.py
import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'you-will-never-guess'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://autoparts:PartsPass456@localhost/auto_parts_store'
    SQLALCHEMY_TRACK_MODIFICATIONS = False