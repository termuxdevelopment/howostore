# app.py
from flask import Flask, render_template, redirect, url_for, flash, request
from config import Config
from models import db, User, Product
from forms import LoginForm, RegistrationForm, AddProductForm
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
import os

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.before_first_request
def create_tables():
    db.create_all()
    # Создание администратора
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin', is_admin=True)
        admin.set_password('admin')
        db.session.add(admin)
        db.session.commit()

@app.route('/')
def index():
    categories = ['Автошины', 'Масляной фильтр', 'Воздушный фильтр', 'Моторные масла', 'Антфриз', 'Аккумуляторы']
    return render_template('index.html', categories=categories)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('Неверный логин или пароль')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        invite_code = form.invite_code.data
        # Здесь должна быть проверка пригласительного кода
        if invite_code == 'your_invite_code':  # Замените на реальную проверку
            user = User(username=form.username.data)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash('Регистрация прошла успешно')
            return redirect(url_for('login'))
        else:
            flash('Неверный пригласительный код')
    return render_template('register.html', form=form)

@app.route('/add_product', methods=['GET', 'POST'])
@login_required
def add_product():
    if not current_user.is_admin:
        flash('У вас нет прав для добавления товаров')
        return redirect(url_for('index'))
    form = AddProductForm()
    if form.validate_on_submit():
        product = Product(
            name=form.name.data,
            quantity=form.quantity.data,
            price=form.price.data,
            brand=form.brand.data,
            diameter=form.diameter.data,
            category=form.category.data
        )
        db.session.add(product)
        db.session.commit()
        flash('Товар добавлен')
        return redirect(url_for('index'))
    return render_template('add_product.html', form=form)

@app.route('/category/<category>')
def category(category):
    products = Product.query.filter_by(category=category).all()
    return render_template('category.html', products=products, category=category)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)