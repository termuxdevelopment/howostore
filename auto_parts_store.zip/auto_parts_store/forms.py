# forms.py
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, FloatField, SelectField
from wtforms.validators import DataRequired, Length, EqualTo

class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired(), Length(min=4, max=25)])
    password = PasswordField('Пароль', validators=[DataRequired()])
    submit = SubmitField('Войти')

class RegistrationForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired(), Length(min=4, max=25)])
    invite_code = StringField('Пригласительный код', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Подтвердите пароль', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Зарегистрироваться')

class AddProductForm(FlaskForm):
    name = StringField('Название', validators=[DataRequired()])
    quantity = IntegerField('Количество', validators=[DataRequired()])
    price = FloatField('Цена', validators=[DataRequired()])
    brand = SelectField('Бренд', choices=[('Michelin', 'Michelin'), ('Aelus', 'Aelus'), ('KAMA', 'KAMA'), ('OMSKRUSSIA', 'OMSKRUSSIA')], validators=[DataRequired()])
    diameter = SelectField('Диаметр', choices=[('17.5', '17.5'), ('22.5', '22.5')], validators=[DataRequired()])
    category = SelectField('Категория', choices=[('Автошины', 'Автошины'), ('Масляной фильтр', 'Масляной фильтр'), ('Воздушный фильтр', 'Воздушный фильтр'), ('Моторные масла', 'Моторные масла'), ('Антфриз', 'Антфриз'), ('Аккумуляторы', 'Аккумуляторы')], validators=[DataRequired()])
    submit = SubmitField('Добавить товар')