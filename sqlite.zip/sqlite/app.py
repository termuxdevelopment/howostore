from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Create Flask application
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///howo_store.db'  # SQLite database
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'your_secret_key'  # Change this to a secure key in production

# Initialize SQLAlchemy
db = SQLAlchemy()
db.init_app(app)

# Import models after initializing db to avoid circular imports
with app.app_context():
    from models import Product, Sale

# Routes
@app.route('/')
def index():
    products = Product.query.all()
    return render_template('index.html', products=products)

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        category = request.form['category']
        brand = request.form['brand']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        
        if category == 'Авто-шины':
            size = request.form['size']
            diameter = request.form['diameter']
            product = Product(category=category, brand=brand, size=size, diameter=diameter, price=price, quantity=quantity)
        elif category == 'Аккумуляторы':
            size = request.form['battery_size']
            product = Product(category=category, brand=brand, size=size, price=price, quantity=quantity)
        else:
            product = Product(category=category, brand=brand, price=price, quantity=quantity)
        
        db.session.add(product)
        db.session.commit()
        flash('Товар успешно добавлен!')
        return redirect(url_for('index'))
    
    return render_template('add_product.html')

@app.route('/delete_product/<int:id>')
def delete_product(id):
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    flash('Товар успешно удален!')
    return redirect(url_for('index'))

@app.route('/sales', methods=['GET', 'POST'])
def sales():
    if request.method == 'POST':
        return redirect(url_for('add_sale'))
    sales = Sale.query.all()
    return render_template('sales.html', sales=sales)

@app.route('/add_sale', methods=['GET', 'POST'])
def add_sale():
    if request.method == 'POST':
        product_type = request.form['product_type']
        quantity = int(request.form['quantity'])
        amount_received = float(request.form['amount_received'])
        sale_date = datetime.strptime(request.form['sale_date'], '%Y-%m-%d')
        
        sale = Sale(product_type=product_type, quantity=quantity, amount_received=amount_received, sale_date=sale_date)
        db.session.add(sale)
        db.session.commit()
        flash('Продажа успешно добавлена!')
        return redirect(url_for('sales'))
    
    return render_template('add_sale.html')

@app.route('/profit')
def profit():
    sales = Sale.query.all()
    profit_by_date = {}
    for sale in sales:
        date_str = sale.sale_date.strftime('%d %b')
        if date_str in profit_by_date:
            profit_by_date[date_str] += sale.amount_received
        else:
            profit_by_date[date_str] = sale.amount_received
    
    return render_template('profit.html', profit_by_date=profit_by_date)

def main():
    with app.app_context():
        db.create_all()  # Create database tables
    app.run(debug=True)

if __name__ == '__main__':
    main()