document.addEventListener('DOMContentLoaded', () => {
    const categorySelect = document.getElementById('category');
    const tireFields = document.getElementById('tire_fields');
    const batteryFields = document.getElementById('battery_fields');

    if (categorySelect) {
        categorySelect.addEventListener('change', () => {
            const category = categorySelect.value;
            tireFields.style.display = category === 'Авто-шины' ? 'block' : 'none';
            batteryFields.style.display = category === 'Аккумуляторы' ? 'block' : 'none';
        });
    }
});