// script.js
console.log('Hello');
