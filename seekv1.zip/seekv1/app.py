from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from models import db, Category, Product, Sale
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///howo_store.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# Создаем базовые категории при первом запуске
def create_categories():
    with app.app_context():
        if not Category.query.first():
            categories = ['Антифриз', 'Моторные масла', 'Автошины', 'Аккумуляторы']
            for name in categories:
                db.session.add(Category(name=name))
            db.session.commit()

create_categories()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/products')
def products():
    categories = Category.query.all()
    products_list = Product.query.all()
    return render_template('products.html', categories=categories, products=products_list)

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    categories = Category.query.all()
    
    if request.method == 'POST':
        try:
            category_id = int(request.form['category'])
            brand = request.form['brand']
            price = float(request.form['price'])
            quantity = int(request.form['quantity'])
            
            attributes = {}
            category = Category.query.get(category_id)
            
            if category.name == 'Автошины':
                attributes['size'] = request.form['size']
                attributes['diameter'] = request.form['diameter']
            elif category.name == 'Аккумуляторы':
                attributes['size'] = request.form['battery_size']
            
            new_product = Product(
                brand=brand,
                price=price,
                quantity=quantity,
                category_id=category_id,
                attributes=attributes
            )
            
            db.session.add(new_product)
            db.session.commit()
            flash('Товар успешно добавлен!', 'success')
            return redirect(url_for('products'))
        
        except Exception as e:
            flash(f'Ошибка: {str(e)}', 'danger')
    
    return render_template('add_product.html', categories=categories)

@app.route('/edit_product/<int:id>', methods=['GET', 'POST'])
def edit_product(id):
    product = Product.query.get_or_404(id)
    categories = Category.query.all()
    
    if request.method == 'POST':
        try:
            product.brand = request.form['brand']
            product.price = float(request.form['price'])
            product.quantity = int(request.form['quantity'])
            category_id = int(request.form['category'])
            
            category = Category.query.get(category_id)
            attributes = {}
            
            if category.name == 'Автошины':
                attributes['size'] = request.form['size']
                attributes['diameter'] = request.form['diameter']
            elif category.name == 'Аккумуляторы':
                attributes['size'] = request.form['battery_size']
            
            product.attributes = attributes
            product.category_id = category_id
            
            db.session.commit()
            flash('Товар успешно обновлен!', 'success')
            return redirect(url_for('products'))
        
        except Exception as e:
            flash(f'Ошибка: {str(e)}', 'danger')
    
    return render_template('edit_product.html', product=product, categories=categories)

@app.route('/delete_product/<int:id>', methods=['POST'])
def delete_product(id):
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    flash('Товар удален!', 'success')
    return redirect(url_for('products'))

@app.route('/sales')
def sales():
    # Получаем продажи за последние 30 дней
    sales_data = Sale.query.filter(
        Sale.sale_date >= datetime.now() - timedelta(days=30)
    ).all()
    
    # Группируем по дням
    daily_sales = {}
    for sale in sales_data:
        date_str = sale.sale_date.strftime('%d %b')
        if date_str not in daily_sales:
            daily_sales[date_str] = 0
        daily_sales[date_str] += sale.amount
    
    return render_template('sales.html', daily_sales=daily_sales)

@app.route('/add_sale', methods=['GET', 'POST'])
def add_sale():
    if request.method == 'POST':
        try:
            product_name = request.form['product_name']
            quantity = int(request.form['quantity'])
            amount = float(request.form['amount'])
            
            new_sale = Sale(
                product_name=product_name,
                quantity=quantity,
                amount=amount
            )
            
            db.session.add(new_sale)
            db.session.commit()
            flash('Продажа добавлена!', 'success')
            return redirect(url_for('sales'))
        
        except Exception as e:
            flash(f'Ошибка: {str(e)}', 'danger')
    
    return render_template('add_sale.html')

if __name__ == '__main__':
    app.run(debug=True)
